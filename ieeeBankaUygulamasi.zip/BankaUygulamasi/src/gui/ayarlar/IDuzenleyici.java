
package gui.ayarlar;


public interface IDuzenleyici { //Frame açıldığında yeniden düzenlemeler için
    
    public void getEdits();
    
}
